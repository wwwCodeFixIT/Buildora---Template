# Buildora v1.0.0

Buildora is a performance-first WordPress block theme for construction, renovation and home-service businesses.

## Highlights

- Full Site Editing / block-theme architecture
- Responsive sticky header and no-JS mobile navigation
- Conversion-focused homepage
- Services, Projects, About and Contact page templates
- Project Case Study template
- Lightweight enquiry form with nonce verification, honeypot protection and throttling
- Editor styles matching the frontend
- No jQuery, no remote fonts and no required frontend JavaScript
- WordPress Playground demo and CI-verified installable ZIP

## Requirements

- WordPress 6.6+
- PHP 8.1+

## Installation

Upload `buildora.zip` through **Appearance → Themes → Add New → Upload Theme**, then activate Buildora.

Buildora does not silently insert demo content into a production database. Create the recommended `Services`, `Projects`, `About` and `Contact` pages when building a full site. Until those pages exist, bundled navigation falls back gracefully to matching sections on the homepage.

See `README.md` and `readme.txt` inside the theme package for full setup details.
